import json
import logging
import boto3
import os
import base64
import io
import json
import logging
from PIL import Image
from botocore.config import Config

from botocore.exceptions import ClientError


class ImageError(Exception):
    "Custom exception for errors returned by Amazon Nova Canvas"

    def __init__(self, message):
        self.message = message

# logger = logging.getLogger(__name__)
# logging.basicConfig(level=logging.INFO)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#===========================S3 Setting===========================
AWS_DEFAULT_REGION="us-west-2"
AWS_ACCESS_KEY_ID="ASIAZQV4TVVDXHGWBODJ"
AWS_SECRET_ACCESS_KEY="oMxUtce7fO3YgqdnCigCvYedfw3DE5dYXgveMf2H"
AWS_SESSION_TOKEN="IQoJb3JpZ2luX2VjEKb//////////wEaCXVzLWVhc3QtMSJGMEQCIDei8GrsWcJ5e6hiPvjDAsg79hJprmgG4VxdzkCx6/mpAiAApMP7r5mw4/4iw5OLLXNW2qtC+XqklRIjBrkQvkbgCSqZAgg+EAAaDDY1NDMwNDMyNDkzNSIM+xAREbVfWkksFmD3KvYBrC50HCKxaMLXKsZ3+bevNd+ozuZ8cVk/iFn/MM53XhJ4eIaHzZFD4pZjX5hJLZnXiHzSHge5BP2i13qsJkXu+Qvm7aAD2BKd0hvBkebVQQTjYAm+8yl14Y+ulla8bf4Ce9KMV26oVw+LmeeLlrZ0V/JfkDUk0wdTcBB6q3tBgifRi6ujngXoYGik9Y7Ys1U7zPnZia1Jqs/vnLyYe9Qo/Az+3JVu99R2jKMFwOQ0G32bq2Eng/2y0P7mV0Sza7GtPW3BT0jVJgazae8XFYOHnSg4NzF1UOIM6MtmBz0HxBLwaGF9uHb3FO7JMHuLFg/zYk03QnFEMKnXscAGOp4Bnj5/tv/nU2j6Xg9fHSPNhSKr0cdXjt7BfP2eyJ9+r7YQwCBzTLuoA7CoKLKZE4MV0Y7A2eVhGyMDJhQ7LDtaI7ti2pmEROaDXk+X0+SG2ELAHNkZMZCga9+9C1UW/V5y1y0v0oFSehvFvuMrTZsmYyCwqb8JAzYFc0QFr4lWElXdl8XBMgfQDRzAfwB94od/OLhTi1g4LDK+blFQLxI="

s3 = boto3.client(
    's3',
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    aws_session_token=AWS_SESSION_TOKEN
)
#===========================S3 Setting===========================

# input: encoded image
# output: S3 path (designed image)


def lambda_handler(event, context):

    """
    Entrypoint for Amazon Nova Canvas  example.
    """
    try:
        logging.basicConfig(level=logging.INFO,
                            format="%(levelname)s: %(message)s")

        model_id = 'amazon.nova-canvas-v1:0'

        # 準備輸入圖片
        # filename_list = ['frame_0.png', 'frame_520.png', 'frame_1040.png']  # 替換為您的圖片路徑
        # input_image = [load_and_encode_image(path) for path in filename_list]

         # 指定你的 S3 bucket 名稱
        bucket_name = 'testviedo'
        # picture_filename = '521793.jpg'
        picture_filename = event['picture_filename']
        print(f"The var is {picture_filename}")
        pure_filename = os.path.basename(picture_filename).split('.')[0]
        download_file_from_s3(bucket_name, picture_filename, picture_filename)
        
        # # Read image from file and encode it as base64 string.
        with open(picture_filename, "rb") as image_file:
            input_image = base64.b64encode(image_file.read()).decode('utf8')

        body = json.dumps({
            "taskType": "IMAGE_VARIATION",
            "imageVariationParams": {
                "text": "Modernize the house, photo-realistic, 8k, hdr",
                "negativeText": "bad quality, low resolution, cartoon",
                "images": [input_image],
                "similarityStrength": 0.95,  # Range: 0.2 to 1.0
            },
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "height": 512,
                "width": 512,
                "cfgScale": 8.0,
                "seed": 300
            }
        })

        response_body = generate_image(model_id=model_id, body=body)

        for i in range(len(response_body.get("images"))):
            base64_image = response_body.get("images")[i]
            base64_bytes = base64_image.encode('ascii')
            image_bytes = base64.b64decode(base64_bytes)

            design_image = Image.open(io.BytesIO(image_bytes))
            design_image.show()
            picture_filename_new = pure_filename+'_designed_002.jpg'
            design_image.save(picture_filename_new)

            # upload file to S3
            upload_file_to_s3(bucket_name, picture_filename_new, picture_filename_new)

        logger.info(f"CloudWatch logs group: {context.log_group_name}")

        data = {"pure_filename": pure_filename}
        return json.dumps(data)

    except ClientError as err:
        message = err.response["Error"]["Message"]
        logger.error("A client error occurred: %s", message)
        print("A client error occured: " +
              format(message))
    except ImageError as err:
        logger.error(err.message)
        print(err.message)

    else:
        print(
            f"Finished generating image with Amazon Nova Canvas  model {model_id}.")

    
def calculate_math(var1, var2):
    return var1+var2

# 上傳檔案到 S3
def upload_file_to_s3(bucket_name, local_file_path, s3_file_key):
    try:
        s3.upload_file(local_file_path, bucket_name, s3_file_key)
        print(f"成功上傳 {local_file_path} 到 s3://{bucket_name}/{s3_file_key}")
    except Exception as e:
        print("上傳失敗：", e)

# 從 S3 下載檔案到本地
def download_file_from_s3(bucket_name, s3_file_key, local_file_path):
    try:
        s3.download_file(bucket_name, s3_file_key, local_file_path)
        print(f"成功從 s3://{bucket_name}/{s3_file_key} 下載到 {local_file_path}")
    except Exception as e:
        print("下載失敗：", e)

def generate_image(model_id, body):
    """
    Generate an image using Amazon Nova Canvas  model on demand.
    Args:
        model_id (str): The model ID to use.
        body (str) : The request body to use.
    Returns:
        image_bytes (bytes): The image generated by the model.
    """

    logger.info(
        "Generating image with Amazon Nova Canvas model %s", model_id)

    bedrock = boto3.client(
        service_name='bedrock-runtime',
        config=Config(read_timeout=300), 
        region_name="us-east-1"
    )

    accept = "application/json"
    content_type = "application/json"

    response = bedrock.invoke_model(
        body=body, modelId=model_id, accept=accept, contentType=content_type
    )
    response_body = json.loads(response.get("body").read())

    finish_reason = response_body.get("error")

    if finish_reason is not None:
        raise ImageError(f"Image generation error. Error is {finish_reason}")

    logger.info(
        "Successfully generated image with Amazon Nova Canvas model %s", model_id)
   

    return response_body

# 載入並編碼圖片
# def load_and_encode_image(image_path):
#     with open(image_path, 'rb') as image_file:
#         return base64.b64encode(image_file.read()).decode('utf-8')










def main(event):
    """
    Entrypoint for Amazon Nova Canvas  example.
    """
    try:
        logging.basicConfig(level=logging.INFO,
                            format="%(levelname)s: %(message)s")

        model_id = 'amazon.nova-canvas-v1:0'

        # 準備輸入圖片
        # filename_list = ['frame_0.png', 'frame_520.png', 'frame_1040.png']  # 替換為您的圖片路徑
        # input_image = [load_and_encode_image(path) for path in filename_list]

         # 指定你的 S3 bucket 名稱
        bucket_name = 'testviedo'
        # picture_filename = '521793.jpg'
        picture_filename = event['picture_filename']
        pure_filename = os.path.basename(picture_filename).split('.')[0]
        download_file_from_s3(bucket_name, picture_filename, picture_filename)
        
        # # Read image from file and encode it as base64 string.
        with open(picture_filename, "rb") as image_file:
            input_image = base64.b64encode(image_file.read()).decode('utf8')

        body = json.dumps({
            "taskType": "IMAGE_VARIATION",
            "imageVariationParams": {
                "text": "Modernize the house, photo-realistic, 8k, hdr",
                "negativeText": "bad quality, low resolution, cartoon",
                "images": [input_image],
                "similarityStrength": 0.95,  # Range: 0.2 to 1.0
            },
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "height": 512,
                "width": 512,
                "cfgScale": 8.0,
                "seed": 300
            }
        })

        response_body = generate_image(model_id=model_id, body=body)

        for i in range(len(response_body.get("images"))):
            base64_image = response_body.get("images")[i]
            base64_bytes = base64_image.encode('ascii')
            image_bytes = base64.b64decode(base64_bytes)

            design_image = Image.open(io.BytesIO(image_bytes))
            design_image.show()
            picture_filename_new = pure_filename+'_designed_002.jpg'
            design_image.save(picture_filename_new)

            # upload file to S3
            upload_file_to_s3(bucket_name, picture_filename_new, picture_filename_new)

        data = {"pure_filename": pure_filename}
        return json.dumps(data)

    except ClientError as err:
        message = err.response["Error"]["Message"]
        logger.error("A client error occurred: %s", message)
        print("A client error occured: " +
              format(message))
    except ImageError as err:
        logger.error(err.message)
        print(err.message)

    else:
        print(
            f"Finished generating image with Amazon Nova Canvas  model {model_id}.")

